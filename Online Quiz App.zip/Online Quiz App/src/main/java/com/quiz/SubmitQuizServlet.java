package com.quiz;

import java.io.IOException;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/submitQuiz")
public class SubmitQuizServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws IOException {

        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");

        String name = request.getParameter("studentName");

        String[] answers = {"A", "B", "C", "B", "A"};

        int score = 0;

        for (int i = 0; i < answers.length; i++) {
            String selected = request.getParameter("q" + (i + 1));

            if (answers[i].equals(selected)) {
                score++;
            }
        }

        int percentage = score * 100 / answers.length;

        String safeName = name == null ? "Student" :
                name.replace("&", "&amp;")
                    .replace("<", "&lt;")
                    .replace(">", "&gt;")
                    .replace("\"", "&quot;")
                    .replace("'", "&#39;");

        String message;

        if (score >= 4) {
            message = "Excellent work!";
        } else if (score >= 3) {
            message = "Good job!";
        } else {
            message = "Keep practising!";
        }

        String css = request.getContextPath() + "/style.css";

        response.getWriter().println(
            "<!DOCTYPE html>" +
            "<html><head>" +
            "<title>Quiz Result</title>" +
            "<link rel='stylesheet' href='" + css + "'>" +
            "</head><body>" +
            "<div class='container'>" +
            "<h1>Quiz Result</h1>" +
            "<h2>Congratulations, " + safeName + "!</h2>" +
            "<h3>Your Score: " + score + " / " + answers.length + "</h3>" +
            "<h3>Percentage: " + percentage + "%</h3>" +
            "<p>" + message + "</p>" +
            "<p><a href='" + request.getContextPath() +
            "/index.html'>Try Again</a></p>" +
            "</div></body></html>"
        );
    }
}